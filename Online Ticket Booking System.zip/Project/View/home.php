<?php
include ("../View/Header.php");
?>

<html>
    <body>
    <link rel="stylesheet" type="text/css" href="../CSS/customerStyle.css">
    </body>
    
    <hr>
    <h1>
    <div class='main-body'>
    <div class="bookbutton"> <a href="customerlogin.php">BOOK NOW</a> </div>
    </div>


    </div>
    </body>
</html>

<?php
include ("Footer.php");
?>
