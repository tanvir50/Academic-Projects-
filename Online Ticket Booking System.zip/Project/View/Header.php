<html>

<head>
<link rel="stylesheet" href="../CSS/main.css">
</head>

    
    <body>
        <table class='header'>
            <tr>
            <td> <img class='nav-logo' src='../Files/logo.jpg' alt='Site Logo'> </td> 
            <td>  <p class='nav-title'>  Online Ticket Booking System &nbsp; &nbsp; &nbsp; </p> </td>
            
            <td class='nav-buttons'> 
                <a href="../View/home.php"> <p> Home </p> </a>
            </td>
           
            </tr>
        </table>    
    </body>
</html>
