<html>
    
    <body>
    
        <hr>
        <table class='footer'>
            <tr>
            
                <td>
                <h2> Discover </h2>
            <a href="customerservice.php"> Customer Services </a> <br>
            <a href="aboutus.php"> About Us </a> <br>
            <a href="refund.php"> Ask for Refund </a> <br>
                    </td>
                    <td>
                    <h2> &nbsp;  </h2>
            <a href="partner.php"> Become a partner </a> <br>
            <a href="terms.php"> Terms & Conditions </a> <br>
            <a href="privacy.php"> Privacy Policy </a> <br>
            </td>
            <td>
                <h2> Payment Method </h2>
                <img src="https://www.gozayaan.com/img/icon-footer-visa.0cc68109.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-payment-dbbl.0975a769.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-footer-mastercard.afdd5b7f.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-footer-amex.a8ead788.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-footer-bkash.a929cde0.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-payment-nagad.2e467251.svg" alt='Visa logo'>
                <img src="https://www.gozayaan.com/img/icon-payment-upay.1b608ec0.svg" alt='Visa logo'>
                
            </td>
            <td>
                    <h2> &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; </h2><br>
                    &nbsp;<br>
                    &nbsp;<br>
            </td>
            <td>
            <h2> Need Help ? </h2> 
            We are Always here for you! Knock us <br> 
            on Messenger anytime or Call our <br> 
            Hotline (10AM - 10PM).<br> 
            </td>
            </td>
            <td>
                    <h2> &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; </h2><br>
                    &nbsp;<br>
                    &nbsp;<br>
            </td>
            <td>
            <h2> Contact </h2> 
            Email - info@ticket.com <br> 
            Phone - 01621086428<br> 
            <br>
            </td>



</tr>
</table>


</body>
</html>